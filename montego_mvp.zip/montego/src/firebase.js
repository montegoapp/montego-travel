
import { initializeApp } from "firebase/app";
import { getDatabase } from "firebase/database";

const firebaseConfig = {
  apiKey: "AIzaSyD9nQfD-a44sh98Udb-5ebsTtOAie556GM",
  authDomain: "montegro-b2d29.firebaseapp.com",
  projectId: "montegro-b2d29",
  storageBucket: "montegro-b2d29.firebasestorage.app",
  messagingSenderId: "467906574757",
  appId: "1:467906574757:web:952420dc4ec0dafefa904c"
};

const app = initializeApp(firebaseConfig);

export const realtimeDB = getDatabase(app);
export default app;
