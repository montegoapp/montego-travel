
const dict = {
  en: {
    appTitle: "Montego",
    role: "Role",
    owner: "Owner",
    guest: "Guest",
    sessionCode: "Session code",
    newSession: "New session",
    apartment: "Apartment",
    setApartmentLocation: "Set apartment location (click on map)",
    startTracking: "Start Tracking",
    stopTracking: "Stop Tracking",
    enterSessionCode: "Enter a session code",
    copy: "Copy",
    trackingStarted: "Tracking started",
    trackingStopped: "Tracking stopped",
    language: "Language",
    me: "Montenegrin",
    en: "English"
  },
  me: {
    appTitle: "Montego",
    role: "Uloga",
    owner: "Vlasnik",
    guest: "Gost",
    sessionCode: "Kod sesije",
    newSession: "Nova sesija",
    apartment: "Apartman",
    setApartmentLocation: "Postavi lokaciju apartmana (klik na mapu)",
    startTracking: "Pokreni praćenje",
    stopTracking: "Zaustavi praćenje",
    enterSessionCode: "Unesite kod sesije",
    copy: "Kopiraj",
    trackingStarted: "Praćenje pokrenuto",
    trackingStopped: "Praćenje zaustavljeno",
    language: "Jezik",
    me: "Crnogorski",
    en: "Engleski"
  }
};

export function createI18n(initial='en') {
  let lang = initial;
  return {
    t(key){ return (dict[lang] && dict[lang][key]) || key },
    get lang(){ return lang },
    setLang(l){ lang = l }
  }
}
