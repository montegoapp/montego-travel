
import React from 'react'
import { GoogleMap, Marker, useJsApiLoader } from '@react-google-maps/api'

const containerStyle = { width: '100%', height: '100vh' }
const defaultCenter = { lat: 42.4411, lng: 19.2627 } // Montenegro

export default function MapView({ apiKey, guestLocation, apartmentLocation, onMapClick }){
  const { isLoaded } = useJsApiLoader({ googleMapsApiKey: apiKey })
  if(!isLoaded) return <div style={{padding:12}}>Loading map…</div>

  return (
    <GoogleMap
      mapContainerStyle={containerStyle}
      center={guestLocation || apartmentLocation || defaultCenter}
      zoom={(guestLocation || apartmentLocation) ? 15 : 8}
      onClick={(e)=> onMapClick && onMapClick({ lat: e.latLng.lat(), lng: e.latLng.lng() })}
    >
      {apartmentLocation && <Marker position={apartmentLocation} />}
      {guestLocation && <Marker position={guestLocation} />}
    </GoogleMap>
  )
}
