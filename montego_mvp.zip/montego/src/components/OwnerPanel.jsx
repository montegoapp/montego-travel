
import React, { useEffect, useState } from 'react'
import { ref, onValue, set } from 'firebase/database'
import { realtimeDB } from '../firebase.js'

export default function OwnerPanel({ t, sessionCode, setSessionCode, apartmentLocation, setApartmentLocation }){
  const [guestLocation, setGuestLocation] = useState(null)

  useEffect(()=>{
    if(!sessionCode) return
    const locRef = ref(realtimeDB, `sessions/${sessionCode}/guestLocation`)
    const unsub = onValue(locRef, (snap)=>{
      setGuestLocation(snap.val() || null)
    })
    return ()=> unsub()
  }, [sessionCode])

  useEffect(()=>{
    if(!sessionCode || !apartmentLocation) return
    set(ref(realtimeDB, `sessions/${sessionCode}/apartment`), apartmentLocation)
  }, [sessionCode, apartmentLocation])

  return (
    <div className="panel card">
      <div style={{display:'grid', gap:8}}>
        <label>{t('sessionCode')}</label>
        <div className="group">
          <input className="input" placeholder={t('enterSessionCode')} value={sessionCode} onChange={e=>setSessionCode(e.target.value)} />
          <button className="btn secondary" onClick={()=>{
            const code = Math.random().toString(36).slice(2,8).toUpperCase()
            setSessionCode(code)
            navigator.clipboard?.writeText(code)
          }}>{t('newSession')}</button>
        </div>

        <strong>{t('apartment')}</strong>
        <div>{t('setApartmentLocation')}</div>
        {apartmentLocation && <small>Lat: {apartmentLocation.lat.toFixed(6)}, Lng: {apartmentLocation.lng.toFixed(6)}</small>}
        {guestLocation && <small>Guest: Lat: {guestLocation.lat?.toFixed?.(6)}, Lng: {guestLocation.lng?.toFixed?.(6)}</small>}
      </div>
    </div>
  )
}
