
import React, { useEffect, useRef, useState } from 'react'
import { ref, onValue, set } from 'firebase/database'
import { realtimeDB } from '../firebase.js'

export default function GuestPanel({ t, sessionCode, setSessionCode, setGuestLocation }){
  const watchIdRef = useRef(null)
  const [apartment, setApartment] = useState(null)
  const [tracking, setTracking] = useState(false)

  useEffect(()=>{
    if(!sessionCode) return
    const aptRef = ref(realtimeDB, `sessions/${sessionCode}/apartment`)
    const unsub = onValue(aptRef, (snap)=> setApartment(snap.val() || null))
    return ()=> unsub()
  }, [sessionCode])

  const startTracking = () => {
    if(!sessionCode) { alert('Enter session code'); return }
    if(!('geolocation' in navigator)) { alert('Geolocation not supported'); return }

    const onSuccess = (pos) => {
      const { latitude: lat, longitude: lng } = pos.coords
      setGuestLocation({ lat, lng })
      set(ref(realtimeDB, `sessions/${sessionCode}/guestLocation`), { lat, lng, ts: Date.now() })
    }
    const onError = (err) => console.error(err)

    const id = navigator.geolocation.watchPosition(onSuccess, onError, {
      enableHighAccuracy: true, maximumAge: 1000, timeout: 10000
    })
    watchIdRef.value = id
    setTracking(true)
    alert(t('trackingStarted'))
  }

  const stopTracking = () => {
    const id = watchIdRef.value
    if(id!=null) navigator.geolocation.clearWatch(id)
    setTracking(false)
    alert(t('trackingStopped'))
  }

  return (
    <div className="panel card">
      <div style={{display:'grid', gap:8}}>
        <label>{t('sessionCode')}</label>
        <div className="group">
          <input className="input" placeholder={t('enterSessionCode')} value={sessionCode} onChange={e=>setSessionCode(e.target.value.toUpperCase())} />
          <button className="btn secondary" onClick={()=> navigator.clipboard?.writeText(sessionCode)}>{t('copy')}</button>
        </div>

        <div className="group">
          {!tracking ? (
            <button className="btn" onClick={startTracking}>🚗 {t('startTracking')}</button>
          ) : (
            <button className="btn secondary" onClick={stopTracking}>⛔ {t('stopTracking')}</button>
          )}
        </div>

        {apartment && <small>Apt: Lat {apartment.lat.toFixed(6)}, Lng {apartment.lng.toFixed(6)}</small>}
      </div>
    </div>
  )
}
