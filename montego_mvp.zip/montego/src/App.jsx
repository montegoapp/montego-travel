
import React, { useMemo, useState } from 'react'
import MapView from './components/MapView.jsx'
import OwnerPanel from './components/OwnerPanel.jsx'
import GuestPanel from './components/GuestPanel.jsx'
import { createI18n } from './i18n.js'

const GOOGLE_MAPS_API_KEY = "AIzaSyC3ihZYw_F8OEEa4TE8Iz7dKkCMGVVOOnE"

export default function App(){
  const [role, setRole] = useState('owner')
  const [lang, setLang] = useState('en')
  const i18n = useMemo(()=> createI18n(lang), [lang])
  const t = i18n.t.bind(i18n)

  const [sessionCode, setSessionCode] = useState('')
  const [apartmentLocation, setApartmentLocation] = useState(null)
  const [guestLocation, setGuestLocation] = useState(null)

  const onMapClick = (coords) => {
    if(role==='owner'){
      setApartmentLocation(coords)
    }
  }

  return (
    <div>
      <div className="topbar">
        <strong>{t('appTitle')}</strong>
        <div className="group">
          <label>{t('role')}:</label>
          <select className="input" value={role} onChange={e=>setRole(e.target.value)}>
            <option value="owner">{t('owner')}</option>
            <option value="guest">{t('guest')}</option>
          </select>
        </div>

        <div className="group">
          <label>{t('language')}:</label>
          <select className="input" value={lang} onChange={e=>setLang(e.target.value)}>
            <option value="en">{t('en')}</option>
            <option value="me">{t('me')}</option>
          </select>
        </div>
      </div>
      <div className="spacer" />

      <MapView
        apiKey={GOOGLE_MAPS_API_KEY}
        guestLocation={guestLocation}
        apartmentLocation={apartmentLocation}
        onMapClick={onMapClick}
      />

      {role==='owner' ? (
        <OwnerPanel
          t={t}
          sessionCode={sessionCode}
          setSessionCode={setSessionCode}
          apartmentLocation={apartmentLocation}
          setApartmentLocation={setApartmentLocation}
        />
      ) : (
        <GuestPanel
          t={t}
          sessionCode={sessionCode}
          setSessionCode={setSessionCode}
          setGuestLocation={setGuestLocation}
        />
      )}
    </div>
  )
}
